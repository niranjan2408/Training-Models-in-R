#Prepare a prediction model for profit of 50_startups data.
#Do transformations for getting better predictions of profit and make a table containing R^2 value for each prepared model.
#R&D Spend -- Research and devolop spend in the past few years
#Administration -- spend on administration in the past few years
#Marketing Spend -- spend on Marketing in the past few years
#State -- states from which data is collected
#Profit  -- profit of each state in the past few years

#Y= Profir
#X1 = R.D.Spend, X2 = Administration, X3 = Marketing.Spend, X4 = State

startups_data <- read.csv(choose.files())

summary(startups_data)
str(startups_data)
sum(is.na(startups_data))

attach(startups_data)
library(moments)
library(corpcor)
library(car)
library(psych)
par(mfrow=c(1,2))

hist(R.D.Spend)
boxplot(R.D.Spend)
skewness(R.D.Spend)
kurtosis(R.D.Spend)

hist(Administration)
boxplot(Administration)
skewness(Administration)
kurtosis(Administration)

hist(Marketing.Spend)
boxplot(Marketing.Spend)
skewness(Marketing.Spend)
kurtosis(Marketing.Spend)

hist(Profit)
boxplot(Profit)
skewness(Profit)
kurtosis(Profit)

startups_data_woStates<-startups_data[-4]
pairs.panels(startups_data_woStates, col="red")
cor(startups_data_woStates)
cor2pcor(cor(startups_data_woStates))


model1<-lm(Profit~.,startups_data_woStates)
summary(model1)
hist(residuals(model1))
boxplot(model1$residuals, horizontal = T)$out
vif(model1)
avPlots(model1)
qqPlot(model1,if.n=5)
influencePlot(model1)
shapiro.test(residuals(model1))



startups_data_woStatesInfluencers<-startups_data_woStates[-c(47,49,50),]
model2<-lm(startups_data_woStatesInfluencers$Profit~.,startups_data_woStatesInfluencers)
summary(model2)
vif(model2)
avPlots(model2)
influenceIndexPlot(model2)
influencePlot(model2)
plot(model2)
qqPlot(model2)
hist(residuals(model2))
boxplot(model2$residuals, horizontal = T)
shapiro.test(residuals(model2))

Final_Model<-lm(startups_data_woStatesInfluencers$Profit~.,startups_data_woStatesInfluencers[,-2])
summary(Final_Model)
hist(residuals(Final_Model))
boxplot(Final_Model$residuals, horizontal = T)
shapiro.test(residuals(Final_Model))
influencePlot(Final_Model)
plot(startups_data_woStatesInfluencers$Profit,resid(Final_Model),ylab="Residuals", xlab="Profit",main="Startups")
abline(0, 0)
plot(Final_Model$fitted.values,startups_data_woStatesInfluencers$Profite,pch = 5, col = c("red", "blue"))

